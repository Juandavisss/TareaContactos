package com.example.tareacontactos

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView


class AdaptadorContactos(var listaContactos:ArrayList<DatosContacto>):
        RecyclerView.Adapter<AdaptadorContactos.ViewHolder>(){

        class ViewHolder(v: View): RecyclerView.ViewHolder(v){
                var nombre :TextView = v.findViewById(R.id.textView)
                var correo :TextView = v.findViewById(R.id.textView5)
                var telefono :TextView = v.findViewById(R.id.textView6)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
                val v: View = LayoutInflater.from(parent.context)
                        .inflate(R.layout.listrecycler, parent, false)
                val viewHolder = ViewHolder(v)
                return viewHolder
        }

        override fun getItemCount(): Int {
                return listaContactos.size
        }

        //lo que devuelves en el onCreate lo coges en los parametros
        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
                holder.nombre.text = listaContactos[position].nombre
                holder.correo.text = listaContactos[position].email
                holder.telefono.text = listaContactos[position].telefono
        }
}