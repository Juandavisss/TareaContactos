package com.example.basededatos

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.SQLException
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log

class DBInterface(private val contexto: Context) {
    private val ayuda: AyudaDB
    private var bd: SQLiteDatabase? = null

    init {
        Log.w(TAG, "creando ayuda")
        ayuda = AyudaDB(contexto)
    }

    @Throws(SQLException::class)
    fun abre(): DBInterface {
        Log.w(TAG, "abrimos base de datos")
        bd = ayuda.writableDatabase
        return this
    }

    // Cierra la BD
    fun cierra() {
        ayuda.close()
    }

    fun insertarContacto(nombre: String?, email: String?): Long {
        val initialValues = ContentValues()
        initialValues.put(CAMPO_NOMBRE, nombre)
        initialValues.put(CAMPO_EMAIL, email)
        return bd!!.insert(
            BD_TABLA, null,
            initialValues
        )
    }

    // Devuelve todos los Contactos
    fun obtenerContactos(): Cursor {
        return bd!!.query(
            BD_TABLA, arrayOf(CAMPO_ID, CAMPO_NOMBRE, CAMPO_EMAIL),
            null, null, null, null,
            null
        )
    }

    fun modificaContacto(id: Long, nombre: String?, email: String?): Long {
        val newValues = ContentValues()
        newValues.put(CAMPO_NOMBRE, nombre)
        newValues.put(CAMPO_EMAIL, email)
        return bd!!.update(BD_TABLA, newValues, CAMPO_ID + "=" + id, null)
            .toLong()
    }

    fun borrarContacto(id: Long): Long {
        return bd!!.delete(BD_TABLA, CAMPO_ID + "=" + id, null)
            .toLong()
    }

    inner class AyudaDB(con: Context?) :
        SQLiteOpenHelper(con, BD_NOMBRE, null, VERSION) {
        init {
            Log.w(TAG, "constructor de ayuda")
        }

        override fun onCreate(db: SQLiteDatabase) {
            try {
                Log.w(TAG, "creando la base de datos " + BD_CREATE)
                db.execSQL(BD_CREATE)
            } catch (e: SQLException) {
                e.printStackTrace()
            }
        }

        override fun onUpgrade(
            db: SQLiteDatabase,
            VersionAntigua: Int, VersionNueva: Int
        ) {
            Log.w(
                TAG, "Actualizando Base de datos de la versión" +
                        VersionAntigua + "A" + VersionNueva + ". Destruirá todos los datos"
            )
            db.execSQL("DROP TABLE IF EXISTS " + BD_TABLA)
            onCreate(db)
        }
    }

    companion object {
        // Constantes
        const val CAMPO_ID: String = "_id"
        const val CAMPO_NOMBRE: String = "nombre"
        const val CAMPO_EMAIL: String = "email"
        const val TAG: String = "DBInterface"

        const val BD_NOMBRE: String = "BDContactos"
        const val BD_TABLA: String = "contactos"
        const val VERSION: Int = 2

        const val BD_CREATE: String = "create table " + BD_TABLA + "(" + CAMPO_ID +
                " integer primary key autoincrement, " +
                CAMPO_NOMBRE + " text not null," +
                CAMPO_EMAIL + " text not null); "
    }
}
