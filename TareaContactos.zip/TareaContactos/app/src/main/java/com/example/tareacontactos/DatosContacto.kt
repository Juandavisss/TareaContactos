package com.example.tareacontactos

//data class solo almacenan datos
data class DatosContacto (
    val nombre: String,
    val email: String,
    val telefono: String
)