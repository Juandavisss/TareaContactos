package com.example.tareacontactos

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val button_entrar = findViewById(R.id.button_entrar) as Button

        //configuramos el evento click para el boton
        button_entrar.setOnClickListener{
            //datos que quiero pasar
            val username = findViewById(R.id.editTextGestion) as EditText
            //recuperamos el valor del editText
            username.text

            //mensaje de ayuda para el programador, para saber si te lee el texto
            //Toast.makeText(this, username.text, Toast.LENGTH_LONG).show()

            val intent = Intent(this, SegundaActividad::class.java)
            intent.putExtra("nombre", username.text)
            startActivity(intent)
        }
    }
}