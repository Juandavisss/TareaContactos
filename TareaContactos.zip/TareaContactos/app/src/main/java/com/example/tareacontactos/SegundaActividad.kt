package com.example.tareacontactos

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.basededatos.DBInterface

class SegundaActividad : AppCompatActivity() {
    var listacontactos: ArrayList<DatosContacto> ?=null
    var adaptadorContactos: AdaptadorContactos ?=null
    var dbInterface: DBInterface?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_segunda_actividad)

        //recupero los datos del intent
        val username = intent.getStringExtra("nombre")

        //muestro los datos en un textView
        val textUser = findViewById<TextView>(R.id.textNombreUser)
        textUser.text = username

        dbInterface = DBInterface(this)
        dbInterface!!.abre()
        cargarContactos()

        var buttonInsertar = findViewById<Button>(R.id.buttonInsertar)
        //Evento para el boton Insertar
        buttonInsertar.setOnClickListener{
            val nombre = findViewById<EditText>(R.id.editTextNombre).text.toString()
            val email = findViewById<EditText>(R.id.editTextEmail).text.toString()
            val telefono = findViewById<EditText>(R.id.editTextTelefono).text.toString()
            if(nombre.isEmpty() || email.isEmpty() || telefono.isEmpty()){
                Toast.makeText(this,"Faltan datos", Toast.LENGTH_LONG).show()
            }else{
                listacontactos!!.add(DatosContacto(nombre, email, telefono))
                //refresca el recyclerView y ? no puede ser nula y no da excepcion y no se ejcuta para que no de esa excepcion
                adaptadorContactos?.notifyDataSetChanged()

            }


        }

    }
    fun cargarContactos() {
        //!!comprobacion de que no puede ser nulo
        val cursor = dbInterface!!.obtenerContactos()
        if (cursor == null) {
            Toast.makeText(this, "No hay contactos", Toast.LENGTH_LONG).show()
        } else {
            listacontactos = ArrayList()
            while (cursor.moveToNext()) {

                val nombre = cursor.getString(1)
                val email = cursor.getString(2)
                val telefono = cursor.getString(3)
                val contacto = DatosContacto(nombre, email, telefono)
                listacontactos!!.add(contacto)
            }
        }
        val rv = findViewById<RecyclerView>(R.id.ListaContactos)
        rv.layoutManager = LinearLayoutManager(this)
        adaptadorContactos = AdaptadorContactos(listacontactos!!)
        rv.adapter = adaptadorContactos
    }

}